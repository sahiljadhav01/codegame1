

module.exports = io => {
    io.on('connection', socket => {
        console.log('New socket connection');

        let currentCode = null;
        
        socket.on('move', function(move) {
            console.log('move detected')
            io.to(currentCode).emit('newMove', move);
            sendRandomQuestion(socket);
        });
        
        socket.on('joinGame', function(data) {
            
            currentCode = data.code;
            socket.join(currentCode);
            if (!games[currentCode]) {
                games[currentCode] = true;
                return;
            }
            io.to(currentCode).emit('startGame');
            sendRandomQuestion(socket);
        });

        socket.on('disconnect', function() {
            console.log('socket disconnected');

            if (currentCode) {
                io.to(currentCode).emit('gameOverDisconnect');
                delete games[currentCode];
            }
        });
        // sendRandomQuestion(socket)
        
        function sendRandomQuestion(socket) {
            // Generate a random index to select a question
            const randomIndex = Math.floor(Math.random() * questions.length);
            const randomQuestion = questions[randomIndex];
            console.log(randomQuestion);
            // Send the random question to the client
            io.to(currentCode).emit('randomQuestion', randomQuestion);
        }
    });
};